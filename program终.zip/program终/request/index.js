export const request = (params) => {
  const baseUrl = "https://api.it120.cc/mengzhiyi"
    return new Promise((resolve,reject) => {
        wx.request({
          ...params,
          url:baseUrl+params.url,
          data:params.data,
          header: {
            "content-type": "application/x-www-form-urlencoded"
          },
          success:(result) => {
            resolve(result)
          },
          fail:(err) => {
            reject(err)
          }
        })
    })
}