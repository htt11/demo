// pages/reAddress/index.js
const WXAPI = require('apifm-wxapi')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    address_del:'',
    id:'',
    provinceId:'',
    cityId:'',
    districtId:'',
    region:[]
  },

  // 地址参数
  address: {
    id:'',
    address: '',
    cityId: '',
    linkMan: '',
    mobile: '',
    provinceId: '',
    districtId:''
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    WXAPI.init('mengzhiyi')
    const id = options.id    
    this.getAddressInfo(id)  
    // this.address.id = id
    this.setData({
      id:id
    })  
  },
  
  // 获取收货地址
  getAddressInfo(id){
    const token = wx.getStorageSync('token');
    wx.request({
      url: 'https://api.it120.cc/mengzhiyi/user/shipping-address/detail/v2',
      data: {
        token,
        id
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: 'GET',
      success: (result) => {
        // console.log(result)
        const address_del = result.data.data.info
        const region = [0,1,2]
        region[0] = result.data.data.info.provinceId
        region[1] = result.data.data.info.cityId
        region[2] = result.data.data.info.districtId
        this.address.id = address_del.id
        this.address.linkMan = address_del.linkMan
        this.address.address = address_del.address
        this.address.mobile = address_del.mobile
        this.address.districtId = address_del.districtId
        this.address.cityId = address_del.cityId
        this.address.provinceId = address_del.provinceId
        this.setData({
          address_del,
          region
        })
      }
    })
  },

   // 收货人
  handleNameInfo(e) {
    this.address.linkMan = e.detail.value
  },
  // 电话
  handlePhoneInfo(e) {
    this.address.mobile = e.detail.value
  },
  // 详细地址
  handleInputInfo(e) {
    this.address.address = e.detail.value
  },
  //省/市/区
  bindRegionChange: function (e) {
    // console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      region: e.detail.value
    })
    this.address.districtId = e.detail.value[2]
    this.address.cityId = e.detail.value[1]
    this.address.provinceId = e.detail.value[0]
  },
  // 修改地址
  changeAddress() {
    const token = wx.getStorageSync('token');
    WXAPI.updateAddress({
      token:token,
      provinceId: this.address.provinceId,
      cityId:this.address.cityId,
      districtId: this.address.districtId,
      linkMan:this.address.linkMan,
      address:this.address.address,
      mobile: this.address.mobile,
      id:this.address.id
    }).then(res => {
      // console.log(res)
    })   
    // 返回address页面
    wx.navigateBack({
      delta:1
    }) 
  }

  
})

