const WXAPI = require('apifm-wxapi')
//获取应用实例
const app = getApp()

Page({
  data: {
    // 轮播图数据
    banners: [],
    navList: [],
  },

  onLoad: function (options) {
    const token = wx.getStorageSync('token')
    if (!token) {
      // 跳转登录页
      wx.navigateTo({
        url: '/pages/login/login'
      });
    }
    
    // this.getNavData()
    WXAPI.init('mengzhiyi')
    WXAPI.banners().then(res => {
      if (res.code == 0) {
        this.setData({
          banners: res.data
        })
      }
    })

   wx.request({
      url: 'https://api.it120.cc/mengzhiyi/cms/category/list',
      header: {
        "content-type": "application/x-www-form-urlencoded"
      },
      success: (result) => {
        // console.log(result)
        this.setData({
          navList: result.data.data
        })
      }
    })
  },

  tapBanner(e) {
    const goodsId = e.currentTarget.dataset.id 
    if (goodsId) { 
      wx.navigateTo({
        url: "/pages/good_detail/index?id=" + goodsId
      })
    }
  }
})