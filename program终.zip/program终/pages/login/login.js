// pages/login/index.js
import {request} from '../../request/index.js'
const WXAPI = require('apifm-wxapi')
Page({

  /**
   * 页面的初始数据
   */
  data: {

  },
  onLoad(options) {
    WXAPI.init('mengzhiyi')
  },
 
  handleGetuserinfo(e){
    // console.log(e)
    // 获取用户信息放入存储
    const {userInfo} = e.detail
    wx.setStorageSync('userInfo', userInfo)
    const {
      encryptedData,
      iv,
      rawData,
      signature
    } = e.detail
    // 获取登录凭证
    wx.login({
      success: (result) => {
        // console.log(result)
        const {code} = result
        // 获取token值
        WXAPI.login_wx(code).then(res => {
          // console.log(res)
          const token = res.data.token
          // 将token加入到缓存
          wx.setStorageSync('token', token);
          // 返回上一个一面
          wx.navigateBack({
            delta: 1
          })
        })
      }
    })
  }
})