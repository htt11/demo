// pages/my/index.js
import {request} from '../../request/index.js'
const WXAPI = require('apifm-wxapi')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    userInfo:{},
    // 收藏商品数量
    collectNum: 0
  },
  onLoad(options) {
    WXAPI.init('mengzhiyi')
  },
  
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    // 获取本地存储中的数据
    const userInfo = wx.getStorageSync('userInfo')
    const collect = wx.getStorageSync('collect') || []
    this.setData({
      userInfo,
      collectNum: collect.length
    })
  },

  handleGetuserinfo(){
    wx.navigateTo({
      url: '/pages/login/login',
    })
  },

  handleAllorder(e){
    const token = wx.getStorageSync('token')
    if (!token) {
      wx.navigateTo({
        url: '/pages/login/login',
      })
    }
    wx.navigateTo({
      url: '/pages/allorder/allorder',
    })
  }

})