import {request} from '../../request/index.js'
const WXAPI = require('apifm-wxapi')

Page({
  data: {
    goodsObj:[],
    detail_tb:[],
    // 商品是否被选中
    isCollect: false,
    
  },
  goodsInfo: {
    goods_id: '',
    goods_num: 0
  },

  onLoad(options) {
    WXAPI.init('mengzhiyi')
    const {id} = options
    // console.log(id)
    this.getDetailInfo(id)
    // 判断商品是否被收藏过
    let {isCollect} = this.data
    let collect = wx.getStorageSync('collect') || []
    // console.log(collect)
    const index = collect.findIndex(v => v.id == id)
    if (index !== -1) {
      // console.log("这里")
      this.setData({
        isCollect:true
      })
      isCollect=true
    }
  },

  //定义方法，获取商品详情数据
  async getDetailInfo(id){
    const result = await request({
      url: '/shop/goods/detail',
      data:{id}
    })
    // console.log(result)
    this.setData({
      goodsObj:result.data.data,
    })
    this.goodsInfo.goods_id = result.data.data.basicInfo.id
    this.goodsInfo.goods_num = 1
    this.setData({
      detail_tb: result.data.data.content.replace(/\<img/gi, '<img style="max-width:100%;height:auto" '),
    })  
  },
  
  // 点击轮播图，放大预览
  handlePreviewImage(e) {
    // console.log('放大预览')
    // console.log(e)
    // 1-先把要预览的图片数据获取到
    const urls = this.data.goodsObj.pics.map(v => v.pic)
    // 2-接收点击时传递的参数
    const current = e.currentTarget.dataset.url
    // console.log(current)
    // 3-展示预览的图片
    wx.previewImage({
      current: current, // 当前显示图片的http链接
      urls: urls // 需要预览的图片http链接列表
    })
  },
  //点击加入购物车
  async handleAddCart(){
    const token = wx.getStorageSync('token');
    // console.log(token)
    if (!token) {
      // 没有，获取，跳转页面登录页面
      wx.navigateTo({
        url: '/pages/login/login'
      });
    } else {
      // 3-有token
      const cartParams = {
        goodsId: this.goodsInfo.goods_id,
        number: this.goodsInfo.goods_num,
        token
      }
      const result = await request({
        url: '/shopping-cart/add',
        data: cartParams,
        method: 'POST'
      })
      // console.log(result)
      wx.showToast({
        title: '加入购物车成功',
        mask: true
      })
    }
  },

  // 商品收藏
  handleCollect() {
    let isCollect = false
    // 获取缓存中收藏的数据
    let collect = wx.getStorageSync('collect') || []
    // 是否被收藏过
    const index = collect.findIndex(v => v.id === this.data.goodsObj.basicInfo.id)
    // console.log(index)
    // -1表示没有查找到
    if (index !== -1) {
      // 收藏过,取消收藏
      collect.splice(index, 1)
      // 更改图标的标识
      isCollect = false
      wx.showToast({
        title: '取消成功',
        mask: true
      })
    } else {
      // 没有收藏过
      collect.push(this.data.goodsObj.basicInfo)
      // 更改图标的标识
      isCollect = true
      this.data.goodsObj.basicInfo.checked = false
      wx.showToast({
        title: '收藏成功',
        mask: true
      })
    }
    // 重新写回缓存
    wx.setStorageSync('collect', collect)
    this.setData({
      isCollect
    })
  }
})
