const WXAPI = require('apifm-wxapi')
import {request} from '../../request/index.js'
Page({
  data: {
    address:{},
    cart:[],
    totalNum:0,
    totalPrice:0
  },
  // 保存购物车商品
  cartInfo: {},

  onLoad: function (options) {
    WXAPI.init('mengzhiyi')
  },
  
  // 获取地址
  async getAddressInfo() {
    const token = wx.getStorageSync('token')
    const result = await request({
      url:'/user/shipping-address/default/v2',
      data: {token},
      method: 'GET'
    })
    // 判断
    if (result.data.msg === "暂无数据") {
      wx.navigateTo({
        url: '/pages/addAddress/addAddress'
      });
    }
    // 地址信息存在
    // console.log(result)
    this.setData({
      address:result.data.data.info
    })
    wx.setStorageSync('conaddress', address)
  },

  // 选择其他收货地址
  chooseAdd(){
    wx.navigateTo({
      url: '/pages/address/address',
    })
  },
  

  onShow() {
    // 显示选中的地址
    const address = wx.getStorageSync('address')
    this.setData({
      address
    })
    wx.setStorageSync('conaddress', address)

    // 获取购物车中数据
    const token = wx.getStorageSync('token')
    // if (!token) {
    //   // 跳转登录页
    //   wx.navigateTo({
    //     url: '/pages/login/login'
    //   });
    // }
    // 有token
    this.getcartinfo()
  },

  // 删除商品
  async handleDel(e){
    // console.log(e)
    const token = wx.getStorageSync('token')
    const key = e.currentTarget.dataset.key
    const res = await request({
      url:'/shopping-cart/remove',
      data:{
        key,
        token
      },
      method:'POST'
    })
    // console.log(res)
    this.onShow()
  },

  // 发送请求获取购物车中数据
  async getcartinfo(){
    const token = wx.getStorageSync('token')
    const result = await request({
      url: '/shopping-cart/info',
      data: {token},
      method: 'GET'
    })
    // console.log(result)
    this.cartInfo = result.data.data
    const cart = result.data.data.items
    let price = result.data.data.price
    let number = result.data.data.number
    this.setData({
      cart,
      totalPrice: price,
      totalNum:number
    })
  },

  async handlePay(){
    const token = wx.getStorageSync('token');
    // 获取购物车中所有商品
    const cartInfo = this.cartInfo.items
    // 发送请求的时候需要的参数
    let goodsJsonStr = []
    cartInfo.forEach((v, i) => {
      goodsJsonStr[i] = {
        "goodsId": v.goodsId,
        "number": v.number
      }
    })
    // 类型转换
    goodsJsonStr = JSON.stringify(goodsJsonStr)
    // console.log(goodsJsonStr) 

    // 判断有没有地址
    const {address} = this.data
    if(!address.linkMan){
      wx.showToast({
        title: '您好，没有收货地址',
        icon:'none',
        duration:2000
      })
      return
    }
    
    // 生成订单
    const result = await request({
      url: '/order/create',
      data: {
        goodsJsonStr,
        token
      },
      method: 'POST',
    })
    // console.log(result)
    wx.showToast({
      title: '订单创建成功'
    })
    
    // 跳转到支付页面
    wx.navigateTo({
      url: '/pages/order_detail/order_detail?id='+result.data.data.id
    })
    // 移除购物车中已经结算的商品
    const res = await request({
      url: '/shopping-cart/empty',
      data: {token},
      method: 'POST',
    })
    // console.log(res)
    this.setData({
      cart:[],
      totalNum:0,
      totalPrice:0
    })
  }
 
})