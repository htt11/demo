// pages/address/index.js
const WXAPI = require('apifm-wxapi')
import {request} from '../../request/index.js'
Page({

  data: {
    addList:[]
  },

  // 获取收货地址
  getAddressInfo(){
    // 1-先去缓存中获取token
    const token = wx.getStorageSync('token');
   //  console.log(token)
    // 2判断
    if (!token) {
      // 3-没有，获取，跳转页面
      wx.navigateTo({
        url: '/pages/login/login'
      })
    } 
  },
  onLoad: function (options) {
    WXAPI.init('mengzhiyi')
    const {id} = options
  },
  onShow: function () {
    // 获取收货地址列表
    this.getAddressList()
  },

  // 封装获取地址信息列表的方法
  getAddressList(){
    const token = wx.getStorageSync('token');
    wx.request({
      url: 'https://api.it120.cc/mengzhiyi/user/shipping-address/list',
      data: {token},
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: 'GET',
      success: (result) => {
        // 判断
        if (result.data.msg === "暂无数据") {
          wx.navigateTo({
            url: '/pages/addAddress/addAddress'
          });
        }
        // 地址信息存在
        const addList=result.data.data 
        // console.log(addList)
        this.setData({
          addList
        })
        
      }
    })
  },
  // 删除地址
  delAddress(e){
    // console.log(e)
    let id = e.currentTarget.dataset.id
    const token = wx.getStorageSync('token');
    wx.showModal({
      title: '操作确认',
      content:'您确定要删除这条地址吗？',
      success:(res)=>{
        // console.log("您点击了确定")
        if(res.confirm){
          // 调用删除方法
          wx.request({
            url: 'https://api.it120.cc/mengzhiyi/user/shipping-address/delete',
            data: {
              token,
              id
            },
            header: {
              'content-type': 'application/x-www-form-urlencoded'
            },
            method: 'POST',
            success: (result) => {
              this.onShow()
              // console.log(result)
            },  
            
          })
          
        }else if(res.cancel){
          console.log("您点击了取消")
        }
      }
    }) 
  },

  async handleAdd(e){
    const token = wx.getStorageSync('token')
    const id = e.currentTarget.dataset.id
    // console.log(id) 
    const res = await request({
      url:'/user/shipping-address/detail/v2',
      method:'GET',
      data:{
        id,
        token
      }
    })
    // console.log(res)
    const address = res.data.data.info
    wx.setStorageSync('address', address)
    wx.navigateBack({
      delta:1
    })
  }
  
})