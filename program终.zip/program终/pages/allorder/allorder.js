const WXAPI = require('apifm-wxapi')
import {request} from '../../request/index.js'
Page({
  data: {
    tabs:[
      {id:0,value:'全部订单',isActive:true},
      {id:1,value:'待付款',isActive:false},
      {id:2,value:'待发货',isActive:false},
      {id:3,value:'已关闭',isActive:false}
    ],
    orderList:[],
    waitList:[],
    deliList:[],
    closeList:[]
  },
 
  onLoad: function (options) {
    WXAPI.init('mengzhiyi')
    // this.getorder()
    // this.getWait()
    // this.getdeli()
    // this.getclose()
  },
  onShow: function () {
    this.getorder()
    this.getWait()
    this.getdeli()
    this.getclose()
  },

  handleTabsItemChange(e){
    // 获取子组件中传递的数据
    let {index} = e.detail
    // 获取tabs数组
    let {tabs} = this.data
    tabs.forEach((val,idx) => {
      idx===index?val.isActive=true:val.isActive=false
    })
    this.setData({
      tabs
    })
  },

  // 获取所有订单
  async getorder(){
    // 获取token
    const token = wx.getStorageSync('token')
    const res = await request({
      url: '/order/list',
      data: {token},
      method: 'POST'
    })
    this.setData({
      orderList:res.data.data.orderList
    })
  },
  // 待支付订单
  async getWait(){
    // 获取token
    const token = wx.getStorageSync('token')
    const res = await request({
      url: '/order/list',
      data: {
        token,
        status:0
      },
      method: 'POST'
    })
    this.setData({
      waitList:res.data.data.orderList
    })
  },
  // 待发货订单
  async getdeli(){
    // 获取token
    const token = wx.getStorageSync('token')
    const res = await request({
      url: '/order/list',
      data: {
        token,
        status:1
      },
      method: 'POST'
    })
    this.setData({
      deliList:res.data.data.orderList
    })
  },
  // 已关闭订单
  async getclose(){
    // 获取token
    const token = wx.getStorageSync('token')
    const res = await request({
      url: '/order/list',
      data: {
        token,
        status:-1
      },
      method: 'POST'
    })
    this.setData({
      closeList:res.data.data.orderList
    })
  }
 
})