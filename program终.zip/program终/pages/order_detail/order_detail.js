// pages/order_detail/order_detail.js
const WXAPI = require('apifm-wxapi')
import {request} from '../../request/index.js'
Page({
  data: {
    address:{},
    orderdetail:[],
    orderinfo:[]
  },
  id:0,
  onLoad: function (options) {
    this.id = options.id
    WXAPI.init('mengzhiyi')
    this.getgooddetail()
  },
  onShow:function(){
    const address=wx.getStorageSync('conaddress')
    this.setData({
      address
    })
  },
  // 支付商品的详情
  async getgooddetail(){
    const token = wx.getStorageSync('token')
    const result = await request({
      url: '/order/detail',
      data: {
        id:this.id,
        token
      },
      method: 'GET'
    })
    const all = result.data.data
    // console.log(all)
    this.setData({
      orderdetail:all.goods,
      orderinfo:all.orderInfo
    })
  },

  async handlePay(e) {
    // 获取要支付的订单
    const orderId = e.currentTarget.dataset.id
    const token = wx.getStorageSync('token')
    const result = await request({
      url: '/order/pay',
      data: {
        orderId,
        token
      },
      method: 'POST'
    })
    // console.log(result)
    wx.showModal({
      title: '支付成功！',
      success :(res)=> {
        if (res.confirm) {
          wx.switchTab({
            url: '/pages/cart/index'
          })
        } 
      }
    })
  }

})