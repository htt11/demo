// pages/collect/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    collect:[],
    hidden:false,
    v:1,
    collectNum:0,
    // 商品是否全选
    allChecked:false,
    // 是否被选中
    // collected:[]
    // 存放要删除商品的id
    delectList:[]
    
  },
    
  onShow: function () {
    // 获取缓存中的收藏信息
    const collect = wx.getStorageSync('collect') || []
    // console.log(collect)
    this.setData({
      collect,
      collectNum: collect.length
    })
    
  },
  //管理/完成的切换
  handleManage(){
    var that = this
    if(this.data.v == 1){
      that.data.v =2
      that.setData({
        hidden:true
      })
      
    }else{
      that.data.v =1
      that.setData({
        hidden:false
      })
    }
  },
  // 商品的选中
  handleItemChange(e) {
    // console.log(e.currentTarget.dataset.checked)
    // 1-获取商品id
    const goods_id = e.currentTarget.dataset.id
    // console.log(goods_id)
    // // 2-获取收藏数组
    let {
      collect
    } = this.data
    // 3-根据id查找对象
    let index = collect.findIndex(v => v.id === goods_id)
    // 4-把选中状态取反
    collect[index].checked = !collect[index].checked
     //5- 全选功能
    // every遍历数组，会接收一个回调函数，每一个回调都返回true，every方法就返回true
    const allChecked = collect.length? collect.every(v => v.checked) :false
    // 6-把数据赋值给data中的数据
    this.setData({
      collect,
      allChecked
    })
    wx.setStorageSync('collect',collect)
  },
  // 商品的全选和反选
  handleAllCheck() {
    // 1-获取data中的allChecked和collect
    let {
      allChecked,
      collect
    } = this.data
    // 2-修改全选值
    allChecked = !allChecked
    // 3-遍历收藏夹商品选中状态
    collect.forEach(v => v.checked = allChecked)
    // 4-全选功能
    allChecked = collect.length? collect.every(v => v.checked) :false
    // 5-把数据赋值给data中的数据
    this.setData({
      collect,
      allChecked
    })
    wx.setStorageSync('collect',collect)
  },
  // 删除已收藏商品
  handleDelete(){
      let {delectList} = this.data
      const collect = wx.getStorageSync('collect') || []
      // console.log("collect.length为"+collect.length)
      for (let i =collect.length-1; i >= 0; i--) {
        // console.log(collect[i].id)
        if(collect[i].checked == true){
          collect.splice(i,1) 
          wx.setStorageSync('collect',collect)
          this.onShow()
        }
        // console.log("collect.length为"+collect.length)
      }
  }

    

  



  
})