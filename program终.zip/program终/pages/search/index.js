import {request} from '../../request/index.js'
const WXAPI = require('apifm-wxapi')

Page({
  data: {
    inputValue: '',
    // 控制按钮是否显示
    isFocus: true,
    // 查询结果数据
    goodsObj: [],
  },
  // 定义一个定时器
  timeId: -1,
  
  onLoad: function (options) {
    WXAPI.init('mengzhiyi')
  },
  // 获取表单中数据
  handleInput(e) {
    // 1-获取输入框中的数据
    let {value} = e.detail
    clearInterval(this.timeId)
    // 2-判断数据的合法性---非空
    if (!value.trim()) {
      // 数据不合法
      this.setData({
        isFocus: true
      })
      return
    }
    // 3-数据合法，修改isFocus显示取消按钮，实现搜索功能
    this.setData({
      isFocus: false
    })
    // 4-请求数据
    this.timeId = setTimeout(() => {
      this.querySearch(value)
    }, 1000)
  },

  // 发送请求搜索数据
  async querySearch(k) {
    const res = await request({
      url:'/shop/goods/list',
      data: {k}
    })
    // console.log(res)
    this.setData({
      goodsObj:res.data.data
    })
  },
  // 取消功能
  handleCancel() {
    this.setData({
      goodsObj:[],
      inputValue:'',
      isFocus: true
    })
  }

})