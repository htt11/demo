const WXAPI = require('apifm-wxapi')
import {request} from '../../request/index.js'
Page({
  /* 页面的初始数据 */
  data: {
    leftAll:[],
    rightGoods:[],
    currentIndex:0,
    // 距离顶部高度
    scrollTop:0
  },
  // 右边所有商品
  rightGoodsAll:[],
  Queryparams:{
    categoryId:'139543'
  },

  /*生命周期函数--监听页面加载*/
  onLoad: function (options) {
    WXAPI.init('mengzhiyi')
    this.getAll()
    // this.getGoodsAll()
    // this.getGoods()

    // 数据放入缓存
    const rightGoodsAll = wx.getStorageSync('rightGoodsAll')
    if(!rightGoodsAll){
      this.getGoodsAll()
      this.getGoods()
    }
    else{
      if(Date.now()-rightGoodsAll.time > 1000*10){
        // 过期，请求数据
        this.getGoodsAll()
        this.getGoods()
      }
      else{
        console.log('获取缓存中的数据')
        this.rightGoodsAll = rightGoodsAll.data
        this.getGoods()
      }
    }
  },

  // 获取左边分类
  async getAll(){ 
    const res = await request({url:'/shop/goods/category/all'})
    // console.log(res)
    this.setData({
      leftAll:res.data.data
    })
  },

  handleItemTap(e){
    // console.log(e)
    let currentIndex = e.currentTarget.dataset.index  
    this.Queryparams.categoryId = e.currentTarget.dataset.id
    this.getGoods()
    this.setData({
      currentIndex,
      scrollTop:0
    })
  },

  // 根据分类id获取相应商品
  async getGoods(){
    const res = await request({
      url:'/shop/goods/list',
      data:this.Queryparams,
    })
    // console.log(res)
    this.setData({
      rightGoods:res.data.data
    })
  },

  // 获取所有商品
  async getGoodsAll(){
    const res = await request({
      url:'/shop/goods/list'
    })
    // console.log(res)
    this.rightGoodsAll = res.data.data
    wx.setStorageSync('rightGoodsAll', {
      time:Date.now(),
      data:this.rightGoodsAll
    })
  },
})