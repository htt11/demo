// pages/feedback/feedback.js
const WXAPI = require('apifm-wxapi')
import {request} from '../../request/index.js'
Page({
  /*页面的初始数据*/
  data: {
    fbtitle:[
      {id:0,value:'产品质量',isActive:true},
      {id:1,value:'产品包装',isActive:false},
      {id:2,value:'物流问题',isActive:false},
      {id:3,value:'其他问题',isActive:false},
    ],
    chooseImg:[],
    txtValue:''
  },
  content:'',
  onLoad: function (options){
    WXAPI.init('mengzhiyi')
  },

  handleTitleChange(e){
    // console.log(e)
    let {index} = e.detail
    let {fbtitle} = this.data
    fbtitle.forEach((val,idx) => {
      idx===index?val.isActive=true:val.isActive=false
    })
    this.setData({
      fbtitle
    })
  },

  // 点击上传图片
  handleChooseImg(){
    wx.chooseImage({
      count:9,
      sizeType:['original','compressed'],
      sourceType:['album','camera'],
      success:(res)=>{
        // console.log(res)
        this.setData({
          chooseImg:[...this.data.chooseImg,...res.tempFilePaths]
        })
      }
    })
  },

  // 删除图片
  handleRemove(e){
    // console.log(e)
    // 要删除的图片及其索引
    const {index} = e.currentTarget.dataset
    const {chooseImg} = this.data
    // 删除图片，更新数据
    chooseImg.splice(index,1)
    this.setData({
      chooseImg
    })
  },
  
  // 获取文本域内容
  handleInput(e){
    this.setData({
      txtValue:e.detail.value
    })
  },

  // 提交
  async handleSumbit(){
    // 文本域中内容
    const {txtValue} = this.data
    // 用户信息
    const userInfo = wx.getStorageSync('userInfo')
    // 判断文本域内容和用户信息
    if(!txtValue){
      wx.showToast({
        title: '意见不能为空!',
        icon:'none',
        duration:1000,
        mask:true
      })
      return
    }
    if(!userInfo.nickName){
      wx.showToast({
        title: '您还没有授权信息!',
        icon:'none',
        duration:1000,
        mask:true
      })
      return
    }
    // 直接提交
    wx.showToast({
      title: '意见反馈成功!',
      duration:1000,
      mask:true
    })
    
    const token = wx.getStorageSync('token')
    const res = await request({
      url:'/comment/add',
      method:'POST',
      data:{
        content:txtValue,
        token
      }
    })
    // console.log(res)
    
    this.setData({
      txtValue:'',
      chooseImg:[]
    })
    // wx.navigateBack({
    //   delta:1
    // })
  }
})