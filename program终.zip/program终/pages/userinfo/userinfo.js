// pages/userinfo/userinfo.js
const WXAPI = require('apifm-wxapi')
import {request} from '../../request/index.js'
Page({

  data: {
    user:[]
  },

  onLoad: function (options) {
    WXAPI.init('mengzhiyi')
  },

  onShow: function () {
    this.getUser()
  },

  async getUser(){
    const token = wx.getStorageSync('token')
    const res = await request({
      url:'/user/detail',
      data:{token},
      method:'GET'
    })
    // console.log(res)
    const user = res.data.data.base
    this.setData({
      user
    })
  },

  handleLarge(){
    const current = this.data.user.avatarUrl
    const urls = this.data.user.avatarUrl
    wx.previewImage({
      current:current,
      urls: [urls]
    })
  }
  
})