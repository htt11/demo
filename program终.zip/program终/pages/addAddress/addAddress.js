// pages/addAddress/index.js
Page({

  /**
   * 页面的初始数据
   */
  data: {
    region: ['省/', '市/', '区'],
    addList:[]
  },

  // 地址参数
  address: {
    address: '',
    cityId: '',
    linkMan: '',
    mobile: '',
    provinceId: '',
    districtId:''
  },
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },
  // 获取数据
  // 收货人
  handleNameInfo(e) {
    this.address.linkMan = e.detail.value
  },
  // 电话
  handlePhoneInfo(e) {
    this.address.mobile = e.detail.value
  },
  // 详细地址
  handleInputInfo(e) {
    this.address.address = e.detail.value
  },
  //省/市/区
  bindRegionChange: function (e) {
    // console.log('picker发送选择改变，携带值为', e.detail.value)
    this.setData({
      region: e.detail.value
    })
    this.address.districtId = e.detail.value[2]
    this.address.cityId = e.detail.value[1]
    this.address.provinceId = e.detail.value[0]
    this.address.all = this.address.provinceId + this.address.cityId +this.address.districtId
   
  },
  // 添加地址
  addAddressInfo() {
    const token = wx.getStorageSync('token');
    const addressParams = {
      ...this.address,
      token
    }
    // console.log(addressParams)
    wx.request({
      url: 'https://api.it120.cc/mengzhiyi/user/shipping-address/add',
      data: addressParams,
      header: {
        'content-type': 'application/x-www-form-urlencoded'
      },
      method: 'POST',
      success: (result) => {
        // console.log(result)
        wx.navigateBack({
          delta:1
        }) 
      }
    })
  }
})

