// pages/detail/detail.js
const WXAPI = require('apifm-wxapi')
import {request} from '../../request/index.js'
Page({

  data: {
    goodDetail:[],
    goodInfo:[]
  },
  id:0,

  onLoad: function (options) {
    WXAPI.init('mengzhiyi')
    this.id = options.id
    this.getdatail()
  },

  async getdatail(){
    const token = wx.getStorageSync('token')
    const result = await request({
      url: '/order/detail',
      data: {
        id:this.id,
        token
      },
      method: 'GET'
    })
    const all = result.data.data
    // console.log(all)
    this.setData({
      goodDetail:all.goods,
      goodInfo:all.orderInfo
    })
  }
})